
import 'package:flutter/material.dart';

class RequestItemsWidget extends StatelessWidget {

  Widget _buildItems(BuildContext context, int index) {
    return Text("RequestItemsWidget");
  }

  @override
  Widget build(BuildContext context) {

    return ListView.builder(
      itemCount: 10,
      itemBuilder: _buildItems,
    );
    
  }
}