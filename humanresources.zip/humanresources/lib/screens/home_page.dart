import 'package:date_picker_timeline/date_picker_widget.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:humanresources/screens/people_model.dart';
import 'package:humanresources/screens/person_details_card.dart';
import 'package:humanresources/screens/profile.dart';
import 'package:humanresources/screens/theme.dart';
import 'package:intl/intl.dart';


import 'calendar.dart';
import 'documents.dart';
import 'employees.dart';
import 'login_screen.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  List<Person> persons=[
    Person(
      name: 'Bill Will',
      img: 'img/pic-7.png',
      job: "Software Developer",
      clock: '3:40',
    ),
    Person(
      name: 'Andy Smith',
      img: 'img/pic-2.png',
      job: "UI Designer",
      clock: '5:50',
    ),
    Person(
      name: 'Julie Robert',
      img: 'img/pic-4.png',
      job: "Software Tester",
      clock: '9:20',
    ),
    Person(
      name: 'Creepy Story',
      img: 'img/pic-5.png',
      job: "UX Researcher",
      clock: '9:20',
    ),
    Person(
      name: 'Cloe Sugar',
      img: 'img/pic-6.png',
      job: "Project manager",
      clock: '9:2O',
    ),
    Person(
      name: 'Colie Story',
      img: 'img/pic-1.png',
      job: "Software Engineer",
      clock: '9:2O',
    )
  ];
  DateTime _selectedDate = DateTime.now();

  @override
  Widget build(BuildContext context) {
    return Scaffold(


      appBar: _appBar(),
      body: Column(
        children: [
          //DATE CONTAINER
          Container(
            margin: const EdgeInsets.only(left: 20, right: 20, top: 10),
            child: Row(
                children: [
                  Container(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(DateFormat.yMMMd().format(DateTime.now()),
                          style: subHeadingStyle,
                        ),
                        Text("Today",
                          style: headingStyle,
                        )
                      ],
                    ),
                  ),
                ]
            ),
          ),
          //CALENDAR CONTAINER
          Container(
            margin: const EdgeInsets.only(top: 20, left: 10),
            child: DatePicker(
              DateTime.now(),
              height: 100,
              width: 80,
              initialSelectedDate: DateTime.now(),
              selectionColor: Colors.brown,
              selectedTextColor: Colors.white,
              dateTextStyle: GoogleFonts.lato(
                textStyle: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                    color: Colors.grey
                ),
              ),
              dayTextStyle: GoogleFonts.lato(
                textStyle: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.grey
                ),
              ),
              monthTextStyle: GoogleFonts.lato(
                textStyle: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Colors.grey
                ),
              ),
              onDateChange: (date) {
                _selectedDate = date;
              },
            ),
          ),
          //EMPLOYEES TEXT
          Container(
            margin: const EdgeInsets.only(right: 200, top: 10, bottom: 10) ,
            child:
            Text("Employees:",
              style: TextStyle(
                  fontSize:23,
                  fontWeight: FontWeight.w600,
                  color: Colors.black54
                   ),
            ),
          ),
          Expanded(child: SingleChildScrollView(
              child: Column(
                children:persons.map((p) {
                  return PersonDetailCard(person:p);
                }).toList()
              ),
          ),
          )

        ],
      ),
      drawer: Drawer(
        child: ListView(
          children:<Widget> [

            ListTile(
              title:Text('Request Leave', style:TextStyle(fontSize: 20),),
              onTap: () {
                Navigator.of(context).pop();
                Navigator.push(context, MaterialPageRoute(builder: (context) => RequestPage()));
              },
            ),
            Divider(color:Colors.black,),
            ListTile(
              title:Text('Calendar/Vacation', style:TextStyle(fontSize: 20),),
              onTap: () {
                Navigator.of(context).pop();
                Navigator.push(context, MaterialPageRoute(builder: (context) => Calendar()));
              },
            ),
            Divider(color:Colors.black,),
            ListTile(
              title:Text('Documents', style:TextStyle(fontSize: 20),),
              onTap: () {
                Navigator.of(context).pop();
                Navigator.push(context, MaterialPageRoute(builder: (context) => Documents()));
              },
            ),
            Divider(color:Colors.black,),
            ListTile(
              title:Text('Log out', style:TextStyle(fontSize: 20),),
              onTap: () {
                logout(context);
              },
            ),
            Divider(color:Colors.black,),
          ],
        ),
      )
    );
  }
//LOGOUT
  Future<void> logout(BuildContext context) async
  {
    await FirebaseAuth.instance.signOut();
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context)=> LoginScreen()));
  }

  _appBar() {
    return AppBar(
      backgroundColor: Colors.amber,
      actions: [
        IconButton(
          icon: Icon(Icons.person,
            size: 20,
          ),
          onPressed: () {
            Navigator.of(context).pop();
            Navigator.push(context, MaterialPageRoute(builder: (context) => Profile()));
          },
        ),
        SizedBox(width: 20,),
      ],
    );

  }

}
