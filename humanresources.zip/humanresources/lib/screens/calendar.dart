import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:humanresources/model/user_model.dart';
import 'package:get/get.dart';

class Calendar extends StatefulWidget {
  const Calendar({Key? key}) : super(key: key);

  @override
  State<Calendar> createState() => _CalendarState();
}

class _CalendarState extends State<Calendar> {
    List list=[];
  List info= [];
  _readData() async{
   await DefaultAssetBundle.of(context).loadString("json/detail.json").then((s){
    setState(() {
      info = json.decode(s);
    });

   });
  }

  User? user= FirebaseAuth.instance.currentUser;
  UserModel loggedInUser = UserModel();

  @override
  void initState() {
    _readData();
    super.initState();

    FirebaseFirestore.instance
        .collection("users")
        .doc(user!.uid)
        .get()
        .then((value){
      this.loggedInUser = UserModel.fromMap(value.data());
      setState(() {

      });
    });
  }

  @override
  Widget build(BuildContext context) {
    double height=MediaQuery.of(context).size.height;
    double width=MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        backgroundColor:Colors.amberAccent,
      ),
      body: Container(
        padding: const EdgeInsets.only( top:70),
        color:Color(0xffe5dac0),
        child: Column(
          children: [
            //james smith
            Container(
              width: width,
              height: 100,
              margin: const EdgeInsets.only(left: 25, right: 25),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color:Color(0xFFebf8fd),
              ),
              child: Container(
                padding: const EdgeInsets.only(left: 20, right: 20),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius:40,
                      backgroundImage: AssetImage(
                          "img/pic-8.png"
                      ),
                    ),
                    SizedBox(width: 10,),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "${loggedInUser.firstName} ${loggedInUser.lastName}",
                          style: TextStyle(
                              color:Color(0xFF3b3f42),
                              fontSize: 15,
                              decoration: TextDecoration.none
                          ),
                        ),
                        SizedBox(height: 5,),
                        Text(
                          "App Developer",
                          style: TextStyle(
                              color:Colors.black45,
                              fontSize: 12,
                              decoration: TextDecoration.none
                          ),
                        ),

                      ],
                    ),
                    Expanded(child: Container()),
                    Container(
                      width: 70,
                      height: 70,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color:Color(0xFFf3fafc)
                      ),
                      child: Center(
                        child: Icon(
                          Icons.assignment,
                          color:Colors.black54,
                          size: 30,
                        ),
                      ),
                    ),

                  ],
                ),
              ),
            ),
            SizedBox(height: 30,),
            //popular contest
            Container(
              padding: const EdgeInsets.only(left: 25, right: 25),
              child: Row(
                children: [
                  Text(
                    "Popular Contest",
                    style: TextStyle(
                        color:Color(0xff1f2326),
                        fontSize: 20,
                        decoration: TextDecoration.none
                    ),
                  ),
                  Expanded(child: Container(
                  )),
                  Text(
                    "Add Task",
                    style: TextStyle(
                        color:Color(0xff030303),
                        fontSize: 15,
                        decoration: TextDecoration.none
                    ),
                  ),

                  SizedBox(width: 5,),
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Color(0xFFfdc33c)
                    ),
                    child: GestureDetector(
                      child: Icon(
                        Icons.add,
                        color:Color(0xfff8f4f4),
                        size: 30,
                      ),
                    ),
                  )
                ],
              ),
            ),
            SizedBox(height: 20,),
            //list
            Container(
              height: 220,
              child: PageView.builder(
                  controller: PageController(viewportFraction: 0.88),
                  itemCount: info.length,
                  itemBuilder: (_, i){
                    return GestureDetector(

                      child: Container(
                        padding: const EdgeInsets.only(left: 20, top: 20),
                        height: 220,
                        width: MediaQuery.of(context).size.width-20,
                        margin: const EdgeInsets.only(right: 10),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(30),
                            color:i.isEven?Color(0xffdfb869):Color(0xff896628)
                        ),
                        child: Column(
                          children: [

                            SizedBox(height: 5,),

                            Row(
                                children:[for(int i=0; i<3; i++)
                                  Container(

                                    width: 50,
                                    height: 50,

                                    child: Container(
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(25),
                                          image: DecorationImage(
                                              image: AssetImage(
                                                  info[i]['img']
                                              ),
                                              fit: BoxFit.cover
                                          )
                                      ),
                                    ),
                                  ),

                                ]
                            ),
                            Divider(thickness: 1.0,),

                            Container(
                                child:Row(
                                  children: [
                                    Text(
                                info[i]['title'],
                                      style: TextStyle(
                                          fontSize: 30,
                                          fontWeight: FontWeight.w500,
                                          color:Colors.white
                                      ),
                                    ),
                                    Expanded(child: Container())
                                  ],
                                )
                            ),
                            SizedBox(height: 10),
                            Container(
                              width: width,
                              child: Text(
                                info[i]["text"],
                                style: TextStyle(
                                    fontSize: 20,
                                    color:Color(0xffb8eefc)
                                ),
                              ),
                            ),

                          ],
                        ),
                      ),
                    );
                  }),
            ),
            SizedBox(height: 30,),
            //recent contests
          ],
        ),
      ),
    );


  }
}
