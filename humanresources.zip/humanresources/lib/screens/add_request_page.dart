import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:humanresources/view_models/add_request_view_model.dart';
import 'leave_requests_list_page.dart';
class AddRequestPage extends StatelessWidget {
  final _formKey = GlobalKey<FormState>();
  AddRequestViewModel _addRequestVM = AddRequestViewModel();

  void _saveRequest(BuildContext context){
    if(_formKey.currentState!.validate()){
      _addRequestVM.saveRequest();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: Text("Add Request")),
        body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                TextFormField(
                  onChanged: (value) => _addRequestVM.requestType= value,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return "Please enter your request type";
                    }
                    return null;
                  },
                  decoration: InputDecoration(hintText: "Enter request type"),
                ),
                TextFormField(
                  onChanged: (value) => _addRequestVM.requestReason= value,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return "Please enter request reason";
                    }
                    return null;
                  },
                  decoration: const InputDecoration(hintText: "Enter leave request reason"),
                ),
                RaisedButton(
                    child: Text("Save", style: TextStyle(color: Colors.white)),
                    onPressed: () {
                    _saveRequest(context);
                    },
                    color: Colors.blue),
                Spacer(),
                Text("")
              ],
            ),
          ),
        ));
  }
}
