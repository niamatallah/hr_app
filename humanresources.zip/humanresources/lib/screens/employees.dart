import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'add_request_page.dart';

class RequestPage extends StatefulWidget {
  const RequestPage({Key? key}) : super(key: key);

  @override
  State<RequestPage> createState() => _RequestPageState();
}

class _RequestPageState extends State<RequestPage> {

 void _navigateToAddLeavePage(BuildContext context){
   Navigator.push(context, MaterialPageRoute(builder: (context)=>AddRequestPage(),
   fullscreenDialog: true));
 }
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        backgroundColor:Colors.amberAccent,
        title: Text("Request Leave"),
        actions: [
          Padding(
              padding: const EdgeInsets.all(8.0),
            child: GestureDetector(
              child: Icon(Icons.add),
              onTap:(){
              _navigateToAddLeavePage(context);
              } ,
            ),
          )
        ],
      ),
      body: Center(
        child: Text('Request Leave', style: TextStyle(fontSize: 22),),
      ),
    );


  }
}


