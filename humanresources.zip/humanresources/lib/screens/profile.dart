import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:humanresources/model/user_model.dart';
import 'package:humanresources/screens/home_page.dart';




class Profile extends StatefulWidget {

  const Profile({Key? key}) : super(key: key);

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  User? user= FirebaseAuth.instance.currentUser;
  UserModel loggedInUser = UserModel();

  @override
  void initState() {
    super.initState();
    FirebaseFirestore.instance
        .collection("users")
        .doc(user!.uid)
        .get()
        .then((value){
      this.loggedInUser = UserModel.fromMap(value.data());
      setState(() {

      });
    });
  }
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        backgroundColor:Colors.amberAccent,
        //Button TO GO BACK
        leading: IconButton(
          icon: Icon(Icons.arrow_back,color: Colors.amber),
          onPressed: (){
            //passing this to the root
            Navigator.of(context).pop();
            Navigator.push(context, MaterialPageRoute(builder: (context) => HomePage()));
          },
        ),
      ),

      //PROFILE PAGE
      body: Container(
        color: Color(0xFFfef9eb),
        child: GestureDetector(
          onTap: (){FocusScope.of(context).unfocus();
          },
          child: Column(
             children: [
               Container(
                 padding: const EdgeInsets.fromLTRB(18, 50, 18, 25),
                 margin: const EdgeInsets.only(bottom: 20),

                 child: Column(
                   children: [

                     Row(
                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
                       children: [

                         Container(
                           height: 80,
                           width: 80,
                           margin: const EdgeInsets.only(left: 30, right: 30),
                           decoration: BoxDecoration(
                             shape: BoxShape.circle,
                              image:DecorationImage (
                               image:AssetImage("img/pic-8.png"),
                             )
                           ),
                         ),
                         Padding(padding: const EdgeInsets.only(right: 30),
                           child: Column(
                             children: [
                               Text("${loggedInUser.firstName} ${loggedInUser.lastName}", style: TextStyle(fontSize: 20, color:Colors.black),),
                               Text("${loggedInUser.email}", style: TextStyle(fontSize: 18, color: Colors.black54),),
                               Text("App Developer", style: TextStyle(fontSize: 15, color: Colors.black45),)
                             ],
                           ) ,
                         )

                       ],
                     ),
                   ],
                 ),
                 decoration: BoxDecoration(
                   borderRadius: BorderRadius.circular(50.0),
                   color: Colors.amber,
                 ),
                 ),
               // BASIC INFO TEXT
               Container(
                 margin: const EdgeInsets.only(right: 200, top: 10, bottom: 10) ,
                 child:
                 Text("Basic Information:",
                   style: TextStyle(
                       fontSize:23,
                       fontWeight: FontWeight.bold,
                       color: Colors.black54
                   ),
                 ),
               ),
                SizedBox(
                 height:35 ,
                ),
                  Expanded( child:SingleChildScrollView(
                    child: Column(
                      children: [
                        buildTextField("Employee #:", "N°5"),
                        buildTextField("First Name:", "${loggedInUser.firstName}"),
                        buildTextField("Last Name:", "${loggedInUser.lastName}"),
                        buildTextField("Company Name:", "INOMI Company Limited"),
                        buildTextField("Field:", "App Development"),
                        buildTextField("Work Email:", "${loggedInUser.email}"),
                        buildTextField("Work Phone:", "801-724-6600x123"),
                      ],
                    ),
        ),
                  ),
            ],
          ),
        ),

      ),

    );
  }
  Widget buildTextField(String labelText, String placeholder){
    return Padding(
      padding: const EdgeInsets.only(bottom: 35.0, left: 10),
      child: TextField(
        decoration: InputDecoration(
            contentPadding: EdgeInsets.only(bottom: 3),
            labelText: labelText,
            floatingLabelBehavior: FloatingLabelBehavior.always,
            hintText: placeholder,
            hintStyle: TextStyle(
              fontSize: 16, fontWeight: FontWeight.normal,
              color: Colors.black,
            )
        ),
      ),
    );
  }
}

