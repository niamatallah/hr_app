
class Person{
  String name;
  String job;
  String img;
  String clock;
  Person({ required this.name, required this.job, required this.img, required this.clock});
}