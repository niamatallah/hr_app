
class Constants {
  static String NO_REQUESTS_FOUND = "No requests found!";
}