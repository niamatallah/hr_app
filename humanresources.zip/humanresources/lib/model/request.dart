import 'package:cloud_firestore/cloud_firestore.dart';
class Request{

  final String type;
  final String reason;
  late DocumentReference reference;


  Request(this.reason, this.type);

  String  get requestId{
    return reference.id;
  }


  Map<String, dynamic> toMap(){
    return{
      "type": type,
      "reason": reason
    };
  }

}