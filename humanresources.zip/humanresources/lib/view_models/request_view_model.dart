import 'package:flutter/rendering.dart';
import 'package:humanresources/model/request.dart';

class RequestViewModel{

  final Request request;
RequestViewModel({required this.request});

String get requestId{
  return request.requestId;
}
String get type{
  return request.type;
}

String get reason{
  return request.reason;
}
}