import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:humanresources/model/request.dart';

class AddRequestViewModel{
  String requestType = "";
  String requestReason = "";

  void saveRequest(){

    final request = Request(requestType, requestReason);

    FirebaseFirestore.instance.collection("requests")
    .add(request.toMap());

  }
}