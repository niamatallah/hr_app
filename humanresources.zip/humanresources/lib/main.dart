import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:humanresources/screens/home_page.dart';
import 'package:humanresources/screens/login_screen.dart';
import 'package:humanresources/screens/person_details_card.dart';

Future <void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp( MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Human resources',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Colors.amberAccent,
        brightness: Brightness.light
      ),
      darkTheme: ThemeData(
          primaryColor: Colors.amberAccent,
          brightness: Brightness.light
      ),
      initialRoute: "/",
      getPages: [
        GetPage(name: "/", page: ()=> LoginScreen())
      ],


    );
  }
}

